--==============================================================================
--PASO 23 - CREACION DE CONSULTA 01.
--==============================================================================

--TABLAS A TRABAJAR
/*
SELECT * FROM BDY1102_P9_1.CLIENTE;

DE ESTA FORMA PODEMOS LLAMAR A LA TABLA DE OTRO USUARIO, PERO EN ESTE CASO, SE
NOS SOLICITA USAR SINONIMOS PARA OCULTAR LOS NOMBRES ORIGINALES.
*/
SELECT * FROM SYN_CLI;      -- TABLA CLIENTE SCLI
SELECT * FROM SYN_CRED_CLI; --TABLA CREDITO CLIENTE SCC

--CONSULTA 01
SELECT
    TO_CHAR(SCLI.NUMRUN,'999G999G999')||'-'||SCLI.DVRUN AS RUN_CLIENTE,
    INITCAP(SCLI.PNOMBRE||' '||SCLI.SNOMBRE||' '||SCLI.APPATERNO||' '||SCLI.APMATERNO) AS NOMBRE_CLIENTE,
    COUNT(SCC.NRO_CLIENTE) AS CREDITOS_SOLICITADOS
FROM
    SYN_CLI SCLI
    JOIN SYN_CRED_CLI SCC ON(SCLI.NRO_CLIENTE = SCC.NRO_CLIENTE)
GROUP BY 
    SCLI.NUMRUN, SCLI.DVRUN, SCLI.PNOMBRE, SCLI.SNOMBRE, SCLI.APPATERNO, SCLI.APMATERNO
ORDER BY
    SCLI.APPATERNO
;

--==============================================================================
--PASO 24 - CREACION DE TABLA SOBRE CONSULTA
--==============================================================================
CREATE TABLE T_INFORME_1 AS
    SELECT
        TO_CHAR(SCLI.NUMRUN,'999G999G999')||'-'||SCLI.DVRUN AS RUN_CLIENTE,
        INITCAP(SCLI.PNOMBRE||' '||SCLI.SNOMBRE||' '||SCLI.APPATERNO||' '||SCLI.APMATERNO) AS NOMBRE_CLIENTE,
        COUNT(SCC.NRO_CLIENTE) AS CREDITOS_SOLICITADOS
    FROM
        SYN_CLI SCLI
        JOIN SYN_CRED_CLI SCC ON(SCLI.NRO_CLIENTE = SCC.NRO_CLIENTE)
    GROUP BY 
        SCLI.NUMRUN, SCLI.DVRUN, SCLI.PNOMBRE, SCLI.SNOMBRE, SCLI.APPATERNO, SCLI.APMATERNO
    ORDER BY
        SCLI.APPATERNO
    ;
    
--*****CONSULTAR TABLA*****
SELECT * FROM T_INFORME_1;

--==============================================================================
--PASO 25 - CREAR VISTA SOBRE TABLA
--==============================================================================
--*****CREACION DE VISTA SOBRE TABLA CREADA*****
CREATE VIEW V_INFORME_1 AS
SELECT * FROM T_INFORME_1;

--*****CONSULTAR INFORME****
SELECT * FROM V_INFORME_1;
    
--==============================================================================
--PASO 26 -- ASIGNAR PERMISO A USUARIO 4 SOBRE VISTA
--==============================================================================
GRANT SELECT ON V_INFORME_1 TO R_USER_4;